Please complete the following informations.
> Expected behavior and actual behavior.
> Steps to reproduce the problem.
> Android or iOS? OS version? Brand? 
> More informations such as error messages and stack traces are welcomed.

请补充如下信息。
> 期望的表现和实际的表现。（如有）
> 问题重现的步骤。（如有）
> Android 还是 iOS？系统版本是多少？手机品牌是什么？（如有）
> 其他的错误信息和堆栈信息如果有也可以一并提供出来。（如有）
> 最好给我们提供可以复现问题的Demo
