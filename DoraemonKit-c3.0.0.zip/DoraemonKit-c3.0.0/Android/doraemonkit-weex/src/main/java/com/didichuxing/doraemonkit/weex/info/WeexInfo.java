package com.didichuxing.doraemonkit.weex.info;

/**
 * @author haojianglong
 * @date 2019-06-25
 */
public class WeexInfo {

    public String key;

    public String value;

    public WeexInfo(String key, String value) {
        this.key = key;
        this.value = value;
    }

}
