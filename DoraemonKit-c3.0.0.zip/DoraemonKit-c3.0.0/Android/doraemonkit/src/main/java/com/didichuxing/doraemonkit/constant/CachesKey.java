package com.didichuxing.doraemonkit.constant;

/**
 * Created by wanglikun on 2018/11/17.
 */

public interface CachesKey {
    String WEB_DOOR_HISTORY = "web_door_history";
    String CRASH_HISTORY = "crash";
    String MOCK_LOCATION = "mock_location";
}