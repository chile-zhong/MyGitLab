package com.didichuxing.doraemonkit.kit.network.bean;

public class NetflowInfo {
    public long flow;
    public long timestamp;
    public String page;
    public boolean isUp;
}
