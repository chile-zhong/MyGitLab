package com.didichuxing.doraemonkit.constant;


public interface SpInputType {
    String BOOLEAN = "Boolean";
    String INTEGER = "Integer";
    String LONG = "Long";
    String FLOAT = "Float";
    String HASHSET = "HashSet";
    String STRING = "String";
}
