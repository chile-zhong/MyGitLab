package com.didichuxing.doraemonkit.constant;

/**
 * Created by wanglikun on 2018/11/20.
 */

public interface BroadcastAction {
    String ACTION_ACCESSIBILITY_UPDATE = "action_accessibility_update";
}