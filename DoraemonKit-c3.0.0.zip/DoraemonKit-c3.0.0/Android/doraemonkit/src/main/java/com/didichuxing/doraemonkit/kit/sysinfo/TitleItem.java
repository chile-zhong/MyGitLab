package com.didichuxing.doraemonkit.kit.sysinfo;

/**
 * @desc:
 */
public class TitleItem extends SysInfoItem {
    public TitleItem(String title) {
        super(title, null);
    }
}
