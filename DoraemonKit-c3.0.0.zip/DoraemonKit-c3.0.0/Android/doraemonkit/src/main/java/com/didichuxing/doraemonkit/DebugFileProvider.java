package com.didichuxing.doraemonkit;

import android.support.v4.content.FileProvider;

/**
 * Created by wanglikun on 2018/11/14.
 */

public class DebugFileProvider extends FileProvider {
}
