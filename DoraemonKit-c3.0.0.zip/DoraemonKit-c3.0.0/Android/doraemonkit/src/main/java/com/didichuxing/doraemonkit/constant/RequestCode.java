package com.didichuxing.doraemonkit.constant;

/**
 * Created by wanglikun on 2018/9/13.
 */

public interface RequestCode {
    int CAPTURE_SCREEN = 10001;
}