package com.didichuxing.doraemonkit.kit.blockmonitor.core;

import com.didichuxing.doraemonkit.kit.blockmonitor.bean.BlockInfo;

public interface OnBlockInfoUpdateListener {
    void onBlockInfoUpdate(BlockInfo blockInfo);
}
