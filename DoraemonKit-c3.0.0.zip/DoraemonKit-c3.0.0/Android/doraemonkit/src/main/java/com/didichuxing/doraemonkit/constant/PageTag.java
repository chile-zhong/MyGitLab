package com.didichuxing.doraemonkit.constant;

/**
 * Created by wanglikun on 2018/10/25.
 */

public interface PageTag {
//    String PAGE_ALIGN_RULER_MARKER = "page_align_ruler_marker";
//    String PAGE_VIEW_CHECK = "page_view_check";
//    String PAGE_COLOR_PICKER_INFO = "page_color_picker_info";
//    String PAGE_TIME_COUNTER = "page_time_counter";
}
